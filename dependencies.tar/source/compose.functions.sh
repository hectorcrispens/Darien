#inicia el volcado del docker-compose.yml
compose(){
    echo "version: \"2\"" >> docker-compose.yml
	echo "services:" >> docker-compose.yml
}

dbcompose(){
    echo " db:" >> docker-compose.yml
	echo "   image: mysql:5.7" >> docker-compose.yml
	echo "   restart: always" >> docker-compose.yml
	echo "   environment:" >> docker-compose.yml
	echo "     MYSQL_DATABASE: 'db'" >> docker-compose.yml
	echo "     # So you don't have to use root, but you can if you like" >> docker-compose.yml
	echo "     MYSQL_USER: 'root'" >> docker-compose.yml
	echo "     # Allow Empty Password" >> docker-compose.yml
	echo "     MYSQL_ALLOW_EMPTY_PASSWORD: 'true'" >> docker-compose.yml
	echo "   ports:" >> docker-compose.yml
	echo "     # <Port exposed> : < MySQL Port running inside container>" >> docker-compose.yml
	echo "     - '3306:3306'" >> docker-compose.yml
	echo "   expose:" >> docker-compose.yml
	echo "     # Opens port 3306 on the container" >> docker-compose.yml
	echo "     - '3306'" >> docker-compose.yml
	echo "     # Where our data will be persisted" >> docker-compose.yml
	echo "   volumes:" >> docker-compose.yml
	echo "     - ./BD:/var/lib/mysql" >> docker-compose.yml
	echo "" >> docker-compose.yml
}

#hace el volcado para el contenedor development
devcompose(){
    echo " dev:" >> docker-compose.yml
    echo "   build: './extras/apache/.'" >> docker-compose.yml
    echo "   ports:" >> docker-compose.yml
    echo "     # <Port exposed> : < MySQL Port running inside container>" >> docker-compose.yml
    echo "     - '80:80'" >> docker-compose.yml
    echo "     - '8000:8000'" >> docker-compose.yml
    echo "   volumes:" >> docker-compose.yml
    echo "     - ./App/apache/:/var/www/html/" >> docker-compose.yml
    echo "     - ./extras/hosts:/etc/hosts" >> docker-compose.yml
    echo "" >> docker-compose.yml
}

nodecompose(){
    echo " node:" >> docker-compose.yml
    echo "   build: './extras/node/.'" >> docker-compose.yml
    echo "   working_dir: /home/node/" >> docker-compose.yml
    echo "   environment:" >> docker-compose.yml
    echo "     - NODE_ENV=development" >> docker-compose.yml
    echo "   volumes:" >> docker-compose.yml
    echo "     - ./App/apache/:/home/apache/" >> docker-compose.yml
    echo "     - ./App/node/:/home/node/" >> docker-compose.yml
    echo "   ports:" >> docker-compose.yml
    echo "     # <Port exposed> : < MySQL Port running inside container>" >> docker-compose.yml
    echo "     - '3000:3000'" >> docker-compose.yml
    echo "" >> docker-compose.yml  
}

ioniccompose(){
    echo " node:" >> docker-compose.yml
    echo "   build: './extras/node/.'" >> docker-compose.yml
    echo "   working_dir: /home/node/" >> docker-compose.yml
    echo "   environment:" >> docker-compose.yml
    echo "     - NODE_ENV=development" >> docker-compose.yml
    echo "   volumes:" >> docker-compose.yml
    echo "     - ./App/node/:/home/node/" >> docker-compose.yml
    echo "   ports:" >> docker-compose.yml
    echo "     # <Port exposed> : < MySQL Port running inside container>" >> docker-compose.yml
    echo "     - '3000:3000'" >> docker-compose.yml
    echo "     - '8100:8100'" >> docker-compose.yml
    echo "" >> docker-compose.yml  
}


