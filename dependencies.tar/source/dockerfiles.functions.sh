devdockerfilefirst(){
    echo 'FROM ubuntu:latest ' >> dockerfile
	echo '' >> dockerfile
	echo 'MAINTAINER Hector ' >> dockerfile
	echo '' >> dockerfile
	echo 'ENV DEBIAN_FRONTEND noninteractive' >> dockerfile
	echo '' >> dockerfile
	echo 'RUN apt-get update && apt-get install -y apache2' >> dockerfile
	echo 'RUN apt-get install -y php' >> dockerfile
	echo 'RUN apt-get install -y curl unzip wget' >> dockerfile
	echo '' >> dockerfile
	echo '# install php-extensions' >> dockerfile
	echo 'RUN apt-get install -y php-cli' >> dockerfile
	echo 'RUN apt-get install -y php-pdo' >> dockerfile
	echo 'RUN apt-get install -y php-mbstring' >> dockerfile
	echo 'RUN apt-get install -y php-mysql' >> dockerfile
	echo 'RUN apt-get install -y php-zip' >> dockerfile
	echo 'RUN apt-get install -y php-xml' >> dockerfile
	echo 'RUN apt-get install -y php-curl' >> dockerfile
	echo '' >> dockerfile
	echo 'RUN curl -sS https://getcomposer.org/installer |php ' >> dockerfile
	echo 'RUN mv composer.phar /usr/local/bin/composer ' >> dockerfile
	echo 'RUN apt-get install -y git' >> dockerfile
}

devdockerfilelast(){
    echo "RUN a2enmod rewrite expires" >> dockerfile
    echo "" >> dockerfile
    echo "# Configure PHP " >> dockerfile
    echo "#ADD typo3.php.ini /etc/php/7.0/apache2/conf.d/ " >> dockerfile
    echo "" >> dockerfile
    echo "# Configure vhost " >> dockerfile
    echo "ADD default.conf /etc/apache2/sites-enabled/000-default.conf" >> dockerfile
    echo "" >> dockerfile
    echo "EXPOSE 80 443 " >> dockerfile
    echo "" >> dockerfile
    echo "WORKDIR /var/www/html " >> dockerfile
    echo "" >> dockerfile
    echo "RUN rm index.html " >> dockerfile
    echo "" >> dockerfile
    echo "CMD [\"apache2ctl\", \"-D\", \"FOREGROUND\"] " >> dockerfile
}

nodedockerfile(){
    echo "FROM node:8" >> dockerfile
    echo "" >> dockerfile
    echo "# Install app dependencies" >> dockerfile
    echo "# A wildcard is used to ensure both package.json AND package-lock.json are copied" >> dockerfile
    echo "# where available (npm@5+)" >> dockerfile
    echo "" >> dockerfile
    echo "RUN npm install express" >> dockerfile
    echo "# If you are building your code for production" >> dockerfile
    echo "# RUN npm ci --only=production" >> dockerfile
    echo "" >> dockerfile
    echo "# Create app directory" >> dockerfile
    echo "WORKDIR /home/node" >> dockerfile
    echo "" >> dockerfile
    echo "EXPOSE 8081" >> dockerfile
    echo "CMD [ \"node\", \"server.js\" ]" >> dockerfile  
}

ionicdockerfile(){
    echo "FROM node:latest" >> dockerfile
    echo "" >> dockerfile
    echo "# Install app dependencies" >> dockerfile
    echo "# A wildcard is used to ensure both package.json AND package-lock.json are copied" >> dockerfile
    echo "# where available (npm@5+)" >> dockerfile
    echo "" >> dockerfile
    echo "RUN npm install @ionic/cli cordova-res" >> dockerfile
    echo "RUN npm install express" >> dockerfile
    echo "# If you are building your code for production" >> dockerfile
    echo "# RUN npm ci --only=production" >> dockerfile
    echo "" >> dockerfile
    echo "# Create app directory" >> dockerfile
    echo "WORKDIR /home/node" >> dockerfile
    echo "" >> dockerfile
    echo "EXPOSE 8100" >> dockerfile
    echo "EXPOSE 3000" >> dockerfile
    echo "CMD [ \"node\", \"server.js\" ]" >> dockerfile  
}
