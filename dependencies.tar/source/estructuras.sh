#crea la estructura basica de directorios
filesystem(){
	mkdir App
	mkdir extras
    mkdir extras/variables
    touch docker-compose.yml
    touch extras/variables/.env
}

#crea la estructura basica para apache
devfilesystem(){
    mkdir App/apache
    mkdir extras/apache
    touch extras/apache/default.conf
    touch extras/hosts
    touch extras/apache/dockerfile
}

#crea la estructura basica para node
nodefilesystem(){
    mkdir App/node
    touch App/node/server.js
    mkdir extras/node
    touch extras/node/dockerfile 
}

