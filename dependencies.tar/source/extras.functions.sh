#hace el volcado de default.conf basico
defaultconf(){
    echo "<VirtualHost *:80>" >> default.conf
	echo "  ServerAdmin webmaster@localhost" >> default.conf
	echo "  DocumentRoot /var/www/html/" >> default.conf
	echo "  SetEnv TYPO3_CONTEXT Development/Docker" >> default.conf
	echo "  <Directory /var/www/html/>" >> default.conf
	echo "    Options Indexes FollowSymLinks" >> default.conf
	echo "    AllowOverride All" >> default.conf
	echo "    Order allow,deny" >> default.conf
	echo "    Allow from all" >> default.conf
	echo "    Require all granted" >> default.conf
	echo "  </Directory>" >> default.conf
	echo "  ErrorLog /error.log" >> default.conf
	echo "  CustomLog /access.log combined" >> default.conf
	echo "</VirtualHost>" >> default.conf
	echo "" >> default.conf
}
#hace el volcado de default.conf para laravel
defaultconflaravel(){
    echo "<VirtualHost *:80>" >> default.conf
    echo "ServerAdmin webmaster@localhost" >> default.conf
    echo "DocumentRoot /var/www/html/$project/public/" >> default.conf
    echo "SetEnv TYPO3_CONTEXT Development/Docker" >> default.conf
    echo "<Directory /var/www/html/$project/public>" >> default.conf
    echo "Options Indexes FollowSymLinks" >> default.conf
    echo "AllowOverride All" >> default.conf
    echo "Order allow,deny" >> default.conf
    echo "Allow from all" >> default.conf
    echo "Require all granted" >> default.conf
    echo "</Directory>" >> default.conf
    echo "ErrorLog /error.log" >> default.conf
    echo "CustomLog /access.log combined" >> default.conf
    echo "</VirtualHost>" >> default.conf  
}

#llena el servidor node
fillserver(){
    echo "var express = require('express');" >> server.js
    echo "var app = express();" >> server.js
    echo "" >> server.js
    echo "app.get('/', function (req, res) {" >> server.js
    echo "res.send('Darien v3.0!');" >> server.js
    echo "});" >> server.js
    echo "" >> server.js
    echo "app.listen(3000, function () {" >> server.js
    echo "console.log('Example app listening on port 3000!');" >> server.js
    echo "});" >> server.js
}

#Hace una copia de seguridad de la carpeta App
backup(){
    rm -r -f Backup
    mkdir Backup
    cp -r App/* Backup
}


#lee el contenido de .tag
readtag(){
    input="extras/variables/.tag"
	taged=""
		while IFS= read -r line
			do
				taged="$line"
		done < "$input"
        echo $taged
}
#lee el contenido de .env
readenv(){
    input="extras/variables/.env"
	enved=""
		while IFS= read -r line
			do
				enved="$line"
		done < "$input"
        echo $enved
}

#llena el servidor node para mostrar las instrucciones de ionic
fillserverionic(){
    echo "var express = require('express');" >> server.js
    echo "var app = express();" >> server.js
    echo "" >> server.js
    echo "app.get('/', function (req, res) {" >> server.js
    echo "res.send('Dentro de la carpeta /home/node hay dos scripts make.sh y serve.sh, ./make.sh crea el proyecto y ./serve.sh levanta el servidor de ionic');" >> server.js
    echo "});" >> server.js
    echo "" >> server.js
    echo "app.listen(3000, function () {" >> server.js
    echo "console.log('Example app listening on port 3000!');" >> server.js
    echo "});" >> server.js
}
