
#Crea un proyecto para apache incluye un contenedor llamado apache y uno de base de datos
buildapache(){
    filesystem
    mkdir BD
    compose
    dbcompose
    devfilesystem
    cd extras
    echo "127.0.0.1   dev.dev" >> hosts
    cd apache
    defaultconf
    devdockerfilefirst
    devdockerfilelast
    cd ..
    cd variables
    echo "dev" >> .env
    cd ..
    cd ..
    devcompose
}

#Crea un proyecto para node, llamado node su contenedor de trabajo y uno de base de datos
buildnode(){
    filesystem
    mkdir BD
    compose
    dbcompose
    nodefilesystem
    cd App/node
    fillserver
    cd ..
    cd ..
    cd extras/node
    nodedockerfile
    cd ..
    cd variables
    echo "node" >> .env
    cd ..
    cd ..
    nodecompose
}

#Crea un proyecto de apache y de node basicos con base de datos
buildfull(){
    filesystem
    mkdir BD
    compose
    dbcompose
    devcompose
    nodecompose
    devfilesystem
    nodefilesystem
    cd App/node
    fillserver
    cd ..
    cd ..
    cd extras/node
    nodedockerfile
    cd ..
    echo "127.0.0.1   dev.dev" >> hosts
    cd apache
    defaultconf
    devdockerfilefirst
    devdockerfilelast
    cd ..
    cd variables
    echo "full" >> .env
    cd ..
    cd ..

    

} 

#Crea un proyecto configurado para laravel incluyendo los archivos make.sh e install.sh
buildlaravel(){
    read -p "Que nombre le dará o tiene el proyecto? : " project
    filesystem
    mkdir BD
    compose
    dbcompose
    devcompose
    nodecompose
    devfilesystem
    nodefilesystem

    cd App/node
    fillserver
    cd ..
    cd apache

    #Archivo make.sh
    touch make.sh
    echo "#!/bin/bash" >> make.sh
    echo "#new laravel app" >> make.sh
    echo "/root/.composer/vendor/bin/laravel new $project" >> make.sh

    #Archivo install.sh
    touch install.sh
    echo "#!/bin/bash" >> install.sh
    echo "#script install.sh para la ejecucion npm install en laravel ruta =App/apache" >> install.sh
    echo "cd \$(ls -p | grep /)" >> install.sh
    echo "npm install" >> install.sh
    cd ..
    cd ..

    #llenar contenido extras
    touch extras/variables/.project
    echo "$project" >> extras/variables/.project
    echo "full" >> extras/variables/.env
    cd extras
    echo "127.0.0.1   development.dev" >> hosts
    cd apache
    defaultconflaravel
    devdockerfilefirst
    echo 'RUN composer global require laravel/installer ' >> dockerfile
    devdockerfilelast
    cd ..
    cd node
    nodedockerfile
    cd ..
    cd ..
    showinsbasico
    showinslara


}

#Crea un proyecto para lumen, incluye contenedor apache y base de datos, no incluye node
buildlumen(){
read -p "Que nombre le dará o tiene el proyecto? : " project
    filesystem
    mkdir BD
    compose
    dbcompose
    devcompose
    devfilesystem
    cd apache

    #Archivo make.sh
    touch make.sh
    echo "#!/bin/bash" >> make.sh
    echo "#new lumen app" >> make.sh
    echo "/root/.composer/vendor/bin/lumen new $project" >> make.sh
    cd ..
    cd ..

    #llenar contenido extras
    touch extras/variables/.project
    echo "$project" >> extras/variables/.project
    echo "dev" >> extras/variables/.env
    cd extras
    echo "127.0.0.1   dev.dev" >> hosts
    cd apache
    defaultconflaravel
    devdockerfilefirst
    echo 'RUN composer global require laravel/lumen-installer' >> dockerfile
    devdockerfilelast
    cd ..
    cd ..
    showinsbasico


}

#Crea un proyecto para ionic. Este solo incluye contenedor para node, sin base de datos
buildionic(){
    filesystem
    compose
    nodefilesystem
    cd App/node
    fillserverionic
    #Archivo ionic.sh
    touch make.sh
    echo "#!/bin/bash" >> make.sh
    echo "#ionic console mask" >> make.sh
    read -p "usted tiene el id de proyecto o crear proyecto nuevo id / new: " choice
    if [ "$choice" = "id" ]; then
    read -p "ingrese el id de proyecto id: " id
    echo "/node_modules/@ionic/cli/bin/ionic start --start-id $id" >> make.sh
    else
    read -p "ingrese el nombre del proyecto nombre: " nombre
    read -p "debe ingresar el tipo (blank, tabs, sidemenu) type: " ty
    echo "/node_modules/@ionic/cli/bin/ionic start $nombre $ty" >> make.sh
    fi

    #Archivo serve.sh
    touch install.sh
    echo "#!/bin/bash" >> install.sh
    echo "#script para levantar el servidor de ionic" >> install.sh
    echo "cd \$(ls -p | grep /)" >> install.sh
    echo "/node_modules/@ionic/cli/bin/ionic serve" >> install.sh
    cd ..
    cd ..
    cd extras/node
    ionicdockerfile
    cd ..
    cd variables
    echo "node" >> .env
    cd ..
    cd ..
    ioniccompose
}

#Levanta el entorno virtual, debe cambiar los permisos de las carpetas
up(){
    chmod 777 -R *
    if [ -e extras/variables/.tag ]; then
		param=$(readtag)
		docker-compose -p ${param} up
	else
		touch extras/variables/.tag
		echo "Debe ingresar un nombre para el grupo de contenedores"
		read -p "name: " name
		echo  "$name" >> extras/variables/.tag
		docker-compose -p ${name} up
	fi

}

#Detiene el enntorno virtual sin eliminar las imagenes
down(){
  if [ -e extras/variables/.tag ]; then
	    input="extras/variables/.tag"
		param=""
		while IFS= read -r line
			do
			param="$line"
			done < "$input" 
		docker-compose -p ${param} down
	else
		touch extras/variables/.tag
		echo "Debe ingresar un nombre para el grupo de contenedores"
		read -p "name: " name
		echo  "$name" >> extras/variables/.tag
		docker-compose -p ${name} down
	fi
}

#conecta con el contenedor de desarrollo, en caso de haber mas de uno pregunta a cual conectar
connect(){
    env=$(readenv)
    tgx=$(readtag)
    if [ "$env" = "full" ]; then
        read -p "Debe escoger a cual contenedor se conectará apache/node: " option
        case "$option" in
        apache)
            docker exec -it ${tgx}_dev_1 /bin/bash
        break
        ;;
        node)
            docker exec -it ${tgx}_node_1 /bin/bash
        break
        ;;
        *) echo "Option $option not recognized" ;;
        esac
    else
     docker exec -it ${tgx}_${env}_1 /bin/bash
    fi
}

#Detiene el entorno y elimina las imagenes, conserva los archivos
clear(){
 down
 environment=$(readenv)
    if [ "$environment" = "full" ]; then
        tag=$(readtag)
        docker rmi ${tag}_development
        docker rmi ${tag}_node
    else
        tg=$(readtag)
        docker rmi ${tg}_${environment}
    fi
}

#Detiene el entorno, elimina las imagenes y borra los archivos, pregunta primero si hace backup
erase(){
    read -p "Desea hacer un backup del contenido de la carpeta App? y/n: " choice
    if [ "$choice" = "y" ]; then 
        backup
    fi
    clear
	rm -f docker-compose.yml
	rm -r -f BD
	rm -r -f App
	rm -r -f extras
	echo "removed all files"
}

