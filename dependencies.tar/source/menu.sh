while [ -n "$1" ]; do # while loop starts

			case "$1" in
			help)
				# muestra toda la ayuda necesaria para administrar el entorno
                if [ "$EUID" -ne 0 ];
                    then
                    showhelp
                    else
                    showhelp
                fi
                
				break
				;;
            make)
                showmake
                read -p "¿Qué tipo de proyecto va a crear? " tipo
                while [ -n "$tipo" ]; do # while loop starts

			        case "$tipo" in
                     apache)
                       buildapache

                      break
                      ;;
                     node)
                       buildnode
                   
                      break
                      ;;
                     full)
                       buildfull
                   
                      break
                      ;;
                     laravel)
                       buildlaravel
                   
                      break
                      ;;
                     lumen)
                       buildlumen
                   
                      break
                      ;;
                     ionic)
                       buildionic
                   
                      break
                      ;;
                     *) echo "Option $tipo not recognized" 
                        break
                     ;;

                     esac
                    shift

                done

                break
                ;;
            up)
                up

                break
                ;;
            down)
                down

                break
                ;;

            clear)
                clear

                break
                ;;
            connect)
                connect

                break
                ;;
            erase)
                erase

                break
                ;;

            --)
                shift

                break
                ;;

             *) echo "Option $1 not recognized" ;;

             esac
       shift

done

