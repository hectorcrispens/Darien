echo ""
echo ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"
echo ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"
echo "::                                                                       ::"
echo -e "::                                     ${Cyan}DARIEN  Versión 3.1 ${Color_Off}              ::"
echo "::                                    Simple command for developers      ::"
echo "::                                                                       ::"
echo ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"
echo ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"
 

#Funciones#
#muestra en pantalla la ayuda
showsudohelp(){
    echo ""
	echo "modo de empleo: darien [OPTION]"
    echo "Como este programa interactúa con otras tecnologías, algunas veces necesita"
    echo "permiso de ADMINISTRADOR, cuando alguna opción tenga una salida con error,"
    echo "pruebe nuevamente como administrador o con sudo"
    echo ""
    echo ""
    #echo "----------------------------------------------------------------[${Cyan} help${Color_Off} ]---"
	echo "${Cyan}help,     ${Red}:Visualiza el contenido de la ayuda ${Color_Off}"
    echo ""
	#echo "----------------------------------------------------------------[ ${Cyan}make ${Color_Off}]---"
	echo "${Cyan}make,     ${Red}:Conjunto de herramientas para creación de proyectos especificos${Color_Off}"
	echo ""
	#echo "------------------------------------------------------------------[ ${Cyan}up${Color_Off} ]---"
	echo "${Cyan}up,       ${Red}:Luego de creado el proyecto, up levanta el entorno virtual${Color_Off}"
	echo ""
	#echo "----------------------------------------------------------------[ ${Cyan}down${Color_Off} ]---"
	echo "${Cyan}down      ${Red}:Detiene la ejecución del entorno, pero sin eliminar las imagenes${Color_Off}"
	echo ""
    #echo "---------------------------------------------------------------[ ${Cyan}clear${Color_Off} ]---"
	echo "${Cyan}clear     ${Red}:Detiene el entorno y elimina las imagenes, ideal para recrear"
	echo "              Cuando hay cambios en los archivos de configuración${Color_Off}"
    #echo "-------------------------------------------------------------[ ${Cyan}connect ${Color_Off}]---"
	echo "${Cyan}connect   ${Red}:Conecta con el contenedor de trabajo${Color_Off}"
	echo ""
    #echo "---------------------------------------------------------------[ ${Cyan}erase ${Color_Off}]---"
	echo "${Cyan}erase     ${Red}:Detiene el entorno y elimina el proyecto junto con los archivos${Color_Off}"
	echo ""
}
showhelp(){
    echo ""
	echo "modo de empleo: darien [OPTION]"
    echo "Como este programa interactúa con otras tecnologías, algunas veces necesita"
    echo "permiso de ADMINISTRADOR, cuando alguna opción tenga una salida con error,"
    echo "pruebe nuevamente como administrador o con sudo"
    echo ""
    echo ""
    #echo -e "----------------------------------------------------------------[${Cyan} help${Color_Off} ]---"
	echo -e "${IRed}help,     ${Cyan}:Visualiza el contenido de la ayuda ${Color_Off}"
    echo ""
	#echo -e "----------------------------------------------------------------[ ${Cyan}make ${Color_Off}]---"
	echo -e "${IRed}make,     ${Cyan}:Conjunto de herramientas para creación de proyectos especificos${Color_Off}"
	echo ""
	#echo -e "------------------------------------------------------------------[ ${Cyan}up${Color_Off} ]---"
	echo -e "${IRed}up,       ${Cyan}:Luego de creado el proyecto, up levanta el entorno virtual${Color_Off}"
	echo ""
	#echo -e "----------------------------------------------------------------[ ${Cyan}down${Color_Off} ]---"
	echo -e "${IRed}down      ${Cyan}:Detiene la ejecución del entorno, pero sin eliminar las imagenes${Color_Off}"
	echo ""
    #echo -e "---------------------------------------------------------------[ ${Cyan}clear${Color_Off} ]---"
	echo -e "${IRed}clear     ${Cyan}:Detiene el entorno y elimina las imagenes, ideal para recrear"
	echo -e "              Cuando hay cambios en los archivos de configuración${Color_Off}"
    #echo -e "-------------------------------------------------------------[ ${Cyan}connect ${Color_Off}]---"
	echo -e "${IRed}connect   ${Cyan}:Conecta con el contenedor de trabajo${Color_Off}"
	echo ""
    #echo -e "---------------------------------------------------------------[ ${Cyan}erase ${Color_Off}]---"
	echo -e "${IRed}erase     ${Cyan}:Detiene el entorno y elimina el proyecto junto con los archivos${Color_Off}"
	echo ""
}

#muestra las opciones de creacion de proyectos
showmake(){
    echo -e ""
    echo -e "A continuación debe ingresar una opción para decidir que tipo de proyecto"
    echo -e "va a construir."
    echo -e "Las opciones se detallan a continuación"
    echo -e "${IRed}apache       ${Cyan}:Proyecto simple para servidor apache y base de datos${Color_Off}"
    echo -e "${IRed}node         ${Cyan}:Proyecto simple para contenedor node y base de datos${Color_Off}"
    echo -e "${IRed}full         ${Cyan}:Proyecto de apache y node con base de datos${Color_Off}"
    echo -e "${IRed}laravel      ${Cyan}:Proyecto preconfigurado para laravel${Color_Off}"
    echo -e "${IRed}lumen        ${Cyan}:Proyecto preconfigurado para lumen ${Color_Off}"
    echo -e "${IRed}ionic        ${Cyan}:Despliegue de proyecto preconfigurado para ionic${Color_Off}"
    echo -e ""
}

#muestra las opciones de creacion de proyectos
showsudomake(){
    echo ""
    echo "A continuación debe ingresar una opción para decidir que tipo de proyecto"
    echo "va a construir."
    echo "Las opciones se detallan a continuación"
    echo "apache       :Proyecto simple para servidor apache y base de datos"
    echo "node         :Proyecto simple para contenedor node y base de datos"
    echo "full         :Proyecto de apache y node con base de datos"
    echo "laravel      :Proyecto preconfigurado para laravel"
    echo "lumen        :Proyecto preconfigurado para lumen "
    echo "ionic        :Despliegue de proyecto preconfigurado para ionic"
    echo ""
}

#muestra las instrucciones basicas luego de levantar proyecto apache
showinsbasico(){
    echo -e ""
    echo -e "A continuación se listan algunas instrucciones para continuar con la crea-"
    echo -e " ción del proyecto"
    echo -e "1-   Conecte el contenedor development con el comando 'sudo darien connect'"
    echo -e "2-   Dentro de la carpeta hay un archivo llamado make.sh debe darle permi-"
    echo -e "      sos y ejecutar './make.sh"

}

#muestra las instrucciones basicas luego de levantar proyecto apache
showsudoinsbasico(){
    echo ""
    echo "A continuación se listan algunas instrucciones para continuar con la crea-"
    echo " ción del proyecto"
    echo "1-   Conecte el contenedor development con el comando 'sudo darien connect'"
    echo "2-   Dentro de la carpeta hay un archivo llamado make.sh debe darle permi-"
    echo "      sos y ejecutar './make.sh"

}

#muetra las instrucciones para npm install de node
showinslara(){
    echo -e "3-   Conecte el contenedor de node con el comando 'sudo darien connect'"
    echo -e "      para instalar los node_modules dentro de un proyecto laravel - "
    echo -e "4-   Dentro de la carpeta home/apache hay un archivo install.sh debe darle"
    echo -e "      permisos y ejecutar el script"
}

#muetra las instrucciones para npm install de node
showsudoinslara(){
    echo "3-   Conecte el contenedor de node con el comando 'sudo darien connect'"
    echo "      para instalar los node_modules dentro de un proyecto laravel - "
    echo "4-   Dentro de la carpeta home/apache hay un archivo install.sh debe darle"
    echo "      permisos y ejecutar el script"
}

