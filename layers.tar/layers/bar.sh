
removechars(){
        size=${#varchar}
        echo ${varchar:0:size-var} 
    }
impresschars(){
     size=${#char}
        echo ${char:0:size-guiones} 
}

progressbar(){
    # Use array sbar['tasks', 'task', 'title', 'x', 'y'] 
   
    tput cup ${sbar[4]} ${sbar[3]}

    #echo -ne "0/100   0%  $title\n[--------------------------------------------------]"
    
    char="██████████████████████████████████████████████████"
    varchar="--------------------------------------------------"
  
        sleep 1
       
        
        porc=$((( ${sbar[1]} * 100 ) / ${sbar[0]} ))
        var=$(((porc * 50) /100))

        guiones=$(( 50 - var ))
        #echo $guiones

       
       
        vl=$(removechars)
        str=$(impresschars)
        color=$Red
        if [ $var -gt "10" ]; then
        color=$Purple
        fi
        if [ $var -gt "20" ]; then
        color=$Yellow
        fi
        if [ $var -gt "30" ]; then
        color=$Cyan
        fi
        if [ $var -gt "40" ]; then
        color=$Green
        fi

        echo -ne "${sbar[1]}/${sbar[0]}  $porc%    ${Cyan}${sbar[2]}${Color_Off}                         \n  [${color}$str$vl${Color_Off}]"

}

