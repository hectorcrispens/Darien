buildapache(){
   lgoo
    builderdev
}

buildnode(){
    lgoo
    buildernode
}

buildfull(){
    lgoo
    builderfull
}

buildlaravel(){
    lgoo
    projectinj=$(getprojectinjector)
    builderfull
    cd App/apache
    makeinjector
    installinjector
    cd ../../
    
}
buildlumen(){
    lgoo
    projectinj=$(getprojectinjector)
    builderdev
    cd App/apache
    makeinjector
    cd ../../
}

buildionic(){
    lgoo
    buildernode
    since="done"
    lsec8
    echo " "
    cd App/node

    makeinjector
    serveinjector
    cd ../../
}

taskup(){
    lgoo
    chmod 777 -R *
    if [ -e extras/variables/.tag ]; then
		param=$(readtag)
		docker-compose -p ${param} up 
	else
		touch extras/variables/.tag
		echo "Debe ingresar un nombre para el grupo de contenedores"
		read -p "name: " name
		echo  "$name" >> extras/variables/.tag
		docker-compose -p ${name} up
	fi
}

taskdown(){
    lgoo
    if [ -e extras/variables/.tag ]; then
	    input="extras/variables/.tag"
		param=""
		while IFS= read -r line
			do
			param="$line"
			done < "$input" 
		docker-compose -p ${param} down > /dev/null 2>&1
	else
		touch extras/variables/.tag
		echo "Debe ingresar un nombre para el grupo de contenedores"
		read -p "name: " name
		echo  "$name" >> extras/variables/.tag
		docker-compose -p ${name} down > /dev/null 2>&1
	fi
}

taskconnect(){
    lgoo
env=$(readenv)
    tgx=$(readtag)
    if [ "$env" = "full" ]; then
        read -p "Debe escoger a cual contenedor se conectará apache/node: " option
        case "$option" in
        apache)
            docker exec -it ${tgx}_dev_1 /bin/bash
        break
        ;;
        node)
            docker exec -it ${tgx}_node_1 /bin/bash
        break
        ;;
        *) echo "Option $option not recognized" ;;
        esac
    else
     docker exec -it ${tgx}_${env}_1 /bin/bash
    fi
}

taskclear(){

taskdown
 environment=$(readenv)
    if [ "$environment" = "full" ]; then
        tag=$(readtag)
        docker rmi ${tag}_development > /dev/null 2>&1
        docker rmi ${tag}_node > /dev/null 2>&1
    else
        tg=$(readtag)
        docker rmi ${tg}_${environment} > /dev/null 2>&1
    fi
}
taskshow(){
    lgoo

    echo ""
    docker ps -a 

}

taskerase(){
    lgoo
     read -p "Desea hacer un backup del contenido de la carpeta App? y/n: " choice
    if [ "$choice" = "y" ]; then 
        backup
    fi
	rm -f docker-compose.yml
	rm -r -f BD
	rm -r -f App
	rm -r -f extras
	echo "removed all files"

}
taskbackup(){
    lgoo
while [ -n "$flag" ]; do # while loop starts

			case "$flag" in
			--full)
             fullbackup
            break
            ;;
            --single)
              backup
            break
            ;;
            
            *)
            backup
            ;;

             esac
       shift
       done
}