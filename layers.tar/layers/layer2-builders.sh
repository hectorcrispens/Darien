builderdev(){
    # Use array sbar['tasks', 'task', 'title', 'x', 'y']
    clear
    lgoo
    sbar=(10 1 "nombre de la red" 2 1)
    progressbar
    echo ""
    networkinj=$(getnetworkinjector)

    sbar=(10 2 "parametros docker" 2 1)
    progressbar
    dockerinj=$(getdockerinjector)

    sbar=(10 3 "definiendo entorno" 2 1)
    progressbar
    envinj=$(getenvironmentinjector)

    sbar=(10 4 "creando archivos" 2 1)
    progressbar
    filesystem

    sbar=(10 5 "insertando compose" 2 1)
    progressbar
    composeinjector

    sbar=(10 6 "insertando docker" 2 1)
    progressbar
    dockerinjector

    sbar=(10 7 "insertando la red" 2 1)
    progressbar
    networkinjector

    sbar=(10 8 "insertando variables" 2 1)
    progressbar
    environmentinjector

    sbar=(10 9 "insertando default.conf" 2 1)
    progressbar
    defaultinjector

    sbar=(10 10 "exito" 2 1)
    progressbar
    echo ""

  
}

buildernode(){
 clear
    lgoo
    sbar=(10 1 "nombre de la red" 2 1)
    progressbar
    echo ""
    networkinj=$(getnetworkinjector)

    sbar=(10 2 "parametros docker" 2 1)
    progressbar
    dockerinj=$(getdockerinjector)
    
    sbar=(10 3 "definiendo entorno" 2 1)
    progressbar
    envinj=$(getenvironmentinjector)
    
    sbar=(10 4 "creando archivos" 2 1)
    progressbar
    filesystem

    sbar=(10 5 "insertando compose" 2 1)
    progressbar
    composeinjector

    sbar=(10 6 "insertando dockerfiles" 2 1)
    progressbar
    dockerinjector

    sbar=(10 7 "insertando la red" 2 1)
    progressbar
    networkinjector

    sbar=(10 8 "insertando variables" 2 1)
    progressbar
    environmentinjector

    sbar=(10 9 "insertando servidor node" 2 1)
    progressbar
     serverinjector

     sbar=(10 10 "exito" 2 1)
    progressbar
    echo ""
 
}

builderfull(){
clear
    lgoo
    sbar=(11 1 "nombre de la red" 2 1)
    progressbar
    echo ""
    networkinj=$(getnetworkinjector)

    sbar=(11 2 "parametros docker" 2 1)
    progressbar
    dockerinj=$(getdockerinjector)

    sbar=(11 3 "definiendo entorno" 2 1)
    progressbar
    envinj=$(getenvironmentinjector)

    sbar=(11 4 "creando archivos" 2 1)
    progressbar
    filesystem

    sbar=(11 5 "insertando compose" 2 1)
    progressbar
    composeinjector

    sbar=(11 6 "insertando dockerfiles" 2 1)
    progressbar
    dockerinjector

    sbar=(11 7 "insertando la red" 2 1)
    progressbar
    networkinjector

    sbar=(11 8 "insertando variables" 2 1)
    progressbar
    environmentinjector

    sbar=(11 9 "insertando servidor node" 2 1)
    progressbar
    serverinjector

    sbar=(11 10 "insertando default.conf" 2 1)
    progressbar
    defaultinjector

    sbar=(11 11 "exito" 2 1)
    progressbar
    echo ""

}
