builderdev(){
    
    networkinj=$(getnetworkinjector)
    since="builderdev"
    echo " "
    lsec1
    dockerinj=$(getdockerinjector)
    
    envinj=$(getenvironmentinjector)

    filesystem
    composeinjector
    dockerinjector
    networkinjector
  environmentinjector
  since="default injector"
  lsec7
    defaultinjector

  
}

buildernode(){

    dockerinj=$(getdockerinjector)
    networkinj=$(getnetworkinjector)
    envinj=$(getenvironmentinjector)
    echo " "
    since="buildernode"
    lsec1
    filesystem
    composeinjector
    dockerinjector
    networkinjector

   
    environmentinjector
    since="server injector"
  lsec7
     serverinjector
 
}

builderfull(){


    dockerinj=$(getdockerinjector)
    networkinj=$(getnetworkinjector)
    envinj=$(getenvironmentinjector)
    echo " "
    since="builderfull"
    lsec1
    filesystem
    composeinjector
    dockerinjector
    networkinjector

    environmentinjector
since="fully injector"
  lsec7
    serverinjector
    defaultinjector


}
