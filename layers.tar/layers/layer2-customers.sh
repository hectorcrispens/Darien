getred(){
    red="default"
     read -p "¿Desea darle un nombre a la red? (Default):  " eleccion
     if [ "$eleccion" != "" ]; then
     red="$eleccion"
     fi
     echo $red
}

getdockerinjector(){
    di=""
    case "$command" in
    laravel)
        di="RUN composer global require laravel/installer "
        ;;
    lumen)
        di="RUN composer global require laravel/lumen-installer"
        ;;
    ionic)
        di="RUN npm install @ionic/cli cordova-res"
        ;;
    *)
        di=""
        ;;

    esac
    echo $di
}

getnetworkinjector(){
ni=""
if [ "$command" != "ionic" ]; then
redname=$(getred)
    case "$flag" in
    *) ni="- $redname"

    ;;
    esac
fi
echo $ni
}
getenvironmentinjector(){
    ei=""
    case "$command" in
    apache)
    ei="dev"
    ;;
    node)
    ei="node"
    ;;
    full)
    ei="full"
    ;;
    laravel)
    ei="full"
    ;;
    lumen)
    ei="dev"
    ;;
    ionic)
    ei="node"
    ;;
    esac
    echo $ei
}
getprojectinjector(){
 read -p "Que nombre le dará o tiene el proyecto? : " project
 echo $project

}
