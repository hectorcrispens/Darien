
#Hace una copia de seguridad de la carpeta App
backup(){
    environ=$(readenv)
    if [ "$environ" = "full" ]; then
    tar -cvf backup.tar App
    else
    tar -cvf backup.tar App/${environ} > /dev/null 2>&1
    fi
}
 fullbackup(){
     tar -cvf full-backup.tar * > /dev/null 2>&1
 }


#lee el contenido de .tag
readtag(){
    input="extras/variables/.tag"
	taged=""
		while IFS= read -r line
			do
				taged="$line"
		done < "$input"
        echo $taged
}
#lee el contenido de .env
readenv(){
    input="extras/variables/.env"
	enved=""
		while IFS= read -r line
			do
				enved="$line"
		done < "$input"
        echo $enved
}
