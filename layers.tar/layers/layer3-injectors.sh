
#crea la estructura basica para apache
devfilesystem(){
    mkdir App/apache > /dev/null 2>&1
    mkdir extras/apache > /dev/null 2>&1
    touch extras/apache/default.conf > /dev/null 2>&1
    touch extras/hosts > /dev/null 2>&1
    touch extras/apache/dockerfile > /dev/null 2>&1
}

#crea la estructura basica para node
nodefilesystem(){
    mkdir App/node > /dev/null 2>&1
    touch App/node/server.js > /dev/null 2>&1
    mkdir extras/node > /dev/null 2>&1
    touch extras/node/dockerfile > /dev/null 2>&1
}

filesystem(){
    
    mkdir App > /dev/null 2>&1
	mkdir extras > /dev/null 2>&1
    mkdir extras/variables > /dev/null 2>&1
    touch docker-compose.yml > /dev/null 2>&1
    touch extras/variables/.env > /dev/null 2>&1
     case "$command" in
        apache)
            mkdir BD > /dev/null 2>&1
            devfilesystem
        ;;
        node)
            mkdir BD > /dev/null 2>&1
            nodefilesystem
        ;;
        laravel)
            mkdir BD > /dev/null 2>&1
            devfilesystem
            nodefilesystem
            touch App/apache/install.sh > /dev/null 2>&1
            touch App/apache/make.sh > /dev/null 2>&1
            
        ;;
        lumen)
            mkdir BD > /dev/null 2>&1
            devfilesystem
        ;;
        full)
            mkdir BD > /dev/null 2>&1
            devfilesystem
            nodefilesystem
        ;;
        ionic)
            nodefilesystem
            touch App/node/make.sh > /dev/null 2>&1
            touch App/node/serve.sh > /dev/null 2>&1
        ;;
        esac

}

dockerinjector(){

    case "$command" in
    apache)
        cd extras/apache
        devdockerfilefirst
        echo "$dockerinj" >> dockerfile
        devdockerfilelast
        cd ../../
        ;;
    node)
        cd extras/node
        nodedockerfilefirst
        nodedockerfilelast
        cd ../../
        ;;
    full)
         cd extras/apache
        devdockerfilefirst
        devdockerfilelast
        cd ../../
        cd extras/node
        nodedockerfilefirst
        nodedockerfilelast
        cd ../../
        ;;
    laravel)
        cd extras/apache
        devdockerfilefirst
        echo "$dockerinj" >> dockerfile
        devdockerfilelast
        cd ../../
        cd extras/node
        nodedockerfilefirst
        nodedockerfilelast
        cd ../../
        ;;
    lumen)
        cd extras/apache
        devdockerfilefirst
        echo "$dockerinj" >> dockerfile
        devdockerfilelast
        cd ../../
        ;;
    ionic)
        cd extras/node
        nodedockerfilefirst
        echo "$dockerinj" >> dockerfile
        echo "EXPOSE 8100" >> dockerfile
        nodedockerfilelast
        cd ../../
        ;;

    esac

}

composeinjector(){
  
    compose
    if [ "$command" != "ionic" ]; then
    dbcompose
    echo "     $networkinj" >> docker-compose.yml
        if [ "$flag" = "--macvlan" ]; then
             echo "       ipv4_address: 192.168.3.4" >> docker-compose.yml
         fi
    fi
    case "$command" in
    apache)
        devcompose
         echo "     $networkinj" >> docker-compose.yml
         if [ "$flag" = "--macvlan" ]; then
         echo "       ipv4_address: 192.168.3.5" >> docker-compose.yml
         fi
         ;;

    node)
        nodecompose
        echo "     $networkinj" >> docker-compose.yml
         if [ "$flag" = "--macvlan" ]; then
         echo "       ipv4_address: 192.168.3.6" >> docker-compose.yml
         fi
         ;;

    full)
        nodecompose
        echo "     $networkinj" >> docker-compose.yml
         if [ "$flag" = "--macvlan" ]; then
         echo "       ipv4_address: 192.168.3.6" >> docker-compose.yml
         fi
         devcompose
         echo "     $networkinj" >> docker-compose.yml
         if [ "$flag" = "--macvlan" ]; then
         echo "       ipv4_address: 192.168.3.5" >> docker-compose.yml
         fi
         ;;

    laravel)
        nodecompose
        echo "     $networkinj" >> docker-compose.yml
         if [ "$flag" = "--macvlan" ]; then
         echo "       ipv4_address: 192.168.3.6" >> docker-compose.yml
         fi
         devcompose
         echo "     $networkinj" >> docker-compose.yml
         if [ "$flag" = "--macvlan" ]; then
         echo "       ipv4_address: 192.168.3.5" >> docker-compose.yml
         fi
         ;;

     lumen)
         devcompose
         echo "     $networkinj" >> docker-compose.yml
         if [ "$flag" = "--macvlan" ]; then
         echo "       ipv4_address: 192.168.3.5" >> docker-compose.yml
         fi
         ;;

     ionic)
        ioniccompose
        ;;



    esac
}

networkinjector(){
   
    if [ "$command" != "ionic" ]; then
    case "$flag" in
    --bridge)
        driver="bridge"
        composenetworks
         ;;
    --host)
        driver="host"
        composenetworks
         ;;
    --macvlan)
        composenetworksmacvlan
         ;;
    *)
        driver="bridge"
        composenetworks
         ;;
    esac
    fi
}

defaultinjector(){
    
    case "$command" in
        apache)
            echo "127.0.0.1   dev.dev" >> extras/hosts
            cd extras/apache
            defaultconf
            cd ../../
        ;;
        full)
            echo "127.0.0.1   dev.dev" >> extras/hosts
            cd extras/apache
            defaultconf
            cd ../../
        ;;
        laravel)
            echo "127.0.0.1   dev.dev" >> extras/hosts
            cd extras/apache
            defaultconflaravel
            cd ../../
        ;;

    esac
}

environmentinjector(){
    
    echo "${envinj}" >> extras/variables/.env
}

serverinjector(){

 case "$command" in 
    ionic)
        cd App/node
        fillserverionic
        cd ../../
        ;;
    *) 
        cd App/node
        fillserver
        cd ../../
        ;;
    esac
}

makeinjector(){
   
    #Archivo make.sh
   if [ "$command" != "ionic" ]; then
        echo "#!/bin/bash" >> make.sh
        echo "#new $command app" >> make.sh
        echo "/root/.composer/vendor/bin/$command new $projectinj" >> make.sh
    else
        echo "#!/bin/bash" >> make.sh
        echo "#ionic console mask" >> make.sh
        read -p "usted tiene el id de proyecto o crear proyecto nuevo id / new: " choice
        if [ "$choice" = "id" ]; then
        read -p "ingrese el id de proyecto id: " id
        echo "/node_modules/@ionic/cli/bin/ionic start --start-id $id" >> make.sh
        else
        read -p "ingrese el nombre del proyecto nombre: " nombre
        read -p "debe ingresar el tipo (blank, tabs, sidemenu) type: " ty
        echo "/node_modules/@ionic/cli/bin/ionic start $nombre $ty" >> make.sh
        fi
    fi

}
installinjector(){
  
    echo "#!/bin/bash" >> install.sh
    echo "#script install.sh para la ejecucion npm install en laravel ruta =App/apache" >> install.sh
    echo "cd \$(ls -p | grep /)" >> install.sh
    echo "npm install" >> install.sh
}

serveinjector(){

    echo "#!/bin/bash" >> serve.sh
    echo "#script para levantar el servidor de ionic" >> serve.sh
    echo "cd \$(ls -p | grep /)" >> serve.sh
    echo "/node_modules/@ionic/cli/bin/ionic serve" >> serve.sh
}


