devdockerfilefirst(){
    echo 'FROM ubuntu:latest ' >> dockerfile
	echo '' >> dockerfile
	echo 'MAINTAINER Hector ' >> dockerfile
	echo '' >> dockerfile
	echo 'ENV DEBIAN_FRONTEND noninteractive' >> dockerfile
	echo '' >> dockerfile
	echo 'RUN apt-get update && apt-get install -y apache2' >> dockerfile
	echo 'RUN apt-get install -y php' >> dockerfile
	echo 'RUN apt-get install -y curl unzip wget' >> dockerfile
	echo '' >> dockerfile
	echo '# install php-extensions' >> dockerfile
	echo 'RUN apt-get install -y php-cli' >> dockerfile
	echo 'RUN apt-get install -y php-pdo' >> dockerfile
	echo 'RUN apt-get install -y php-mbstring' >> dockerfile
	echo 'RUN apt-get install -y php-mysql' >> dockerfile
	echo 'RUN apt-get install -y php-zip' >> dockerfile
	echo 'RUN apt-get install -y php-xml' >> dockerfile
	echo 'RUN apt-get install -y php-curl' >> dockerfile
	echo '' >> dockerfile
	echo 'RUN curl -sS https://getcomposer.org/installer |php ' >> dockerfile
	echo 'RUN mv composer.phar /usr/local/bin/composer ' >> dockerfile
	echo 'RUN apt-get install -y git' >> dockerfile
}

devdockerfilelast(){
    echo "RUN a2enmod rewrite expires" >> dockerfile
    echo "" >> dockerfile
    echo "# Configure PHP " >> dockerfile
    echo "#ADD typo3.php.ini /etc/php/7.0/apache2/conf.d/ " >> dockerfile
    echo "" >> dockerfile
    echo "# Configure vhost " >> dockerfile
    echo "ADD default.conf /etc/apache2/sites-enabled/000-default.conf" >> dockerfile
    echo "" >> dockerfile
    echo "EXPOSE 80 443 " >> dockerfile
    echo "" >> dockerfile
    echo "WORKDIR /var/www/html " >> dockerfile
    echo "" >> dockerfile
    echo "RUN rm index.html " >> dockerfile
    echo "" >> dockerfile
    echo "CMD [\"apache2ctl\", \"-D\", \"FOREGROUND\"] " >> dockerfile
}


nodedockerfilefirst(){
echo "FROM node:latest" >> dockerfile
    echo "" >> dockerfile
    echo "# Install app dependencies" >> dockerfile
    echo "# A wildcard is used to ensure both package.json AND package-lock.json are copied" >> dockerfile
    echo "# where available (npm@5+)" >> dockerfile
    echo "" >> dockerfile
}

nodedockerfilelast(){
    echo "RUN npm install express" >> dockerfile
    echo "# If you are building your code for production" >> dockerfile
    echo "# RUN npm ci --only=production" >> dockerfile
    echo "" >> dockerfile
    echo "# Create app directory" >> dockerfile
    echo "WORKDIR /home/node" >> dockerfile
    echo "" >> dockerfile
    echo "EXPOSE 3000" >> dockerfile
    echo "CMD [ \"node\", \"server.js\" ]" >> dockerfile  
}


#inicia el volcado del docker-compose.yml
compose(){
    echo "version: \"2\"" >> docker-compose.yml
	echo "services:" >> docker-compose.yml
}

dbcompose(){
    echo " db:" >> docker-compose.yml
	echo "   image: mysql:5.7" >> docker-compose.yml
	echo "   restart: always" >> docker-compose.yml
	echo "   environment:" >> docker-compose.yml
	echo "     MYSQL_DATABASE: 'db'" >> docker-compose.yml
	echo "     # So you don't have to use root, but you can if you like" >> docker-compose.yml
	echo "     MYSQL_USER: 'root'" >> docker-compose.yml
	echo "     # Allow Empty Password" >> docker-compose.yml
	echo "     MYSQL_ALLOW_EMPTY_PASSWORD: 'true'" >> docker-compose.yml
	echo "   ports:" >> docker-compose.yml
	echo "     # <Port exposed> : < MySQL Port running inside container>" >> docker-compose.yml
	echo "     - '3306:3306'" >> docker-compose.yml
	echo "   expose:" >> docker-compose.yml
	echo "     # Opens port 3306 on the container" >> docker-compose.yml
	echo "     - '3306'" >> docker-compose.yml
	echo "     # Where our data will be persisted" >> docker-compose.yml
	echo "   volumes:" >> docker-compose.yml
	echo "     - ./BD:/var/lib/mysql" >> docker-compose.yml
	echo "   networks:" >> docker-compose.yml
}

composebridge(){
    echo "   networks:" >> docker-compose.yml
	echo "     - ${networkinj}" >> docker-compose.yml
	#echo "" >> docker-compose.yml
}

dbcomposemacvlan(){
    echo "   networks:" >> docker-compose.yml
    echo "     ${networkinj}:" >> docker-compose.yml
    echo "       ipv4_address: '192.168.3.2'" >> docker-compose.yml
    #echo "" >> docker-compose.yml
}

nodecomposemacvlan(){
    echo "   networks:" >> docker-compose.yml
    echo "     ${networkinj}:" >> docker-compose.yml
    echo "       ipv4_address: '192.168.3.3'" >> docker-compose.yml
    #echo "" >> docker-compose.yml
}

devcomposemacvlan(){
    echo "" >> docker-compose.yml
    echo "   networks:" >> docker-compose.yml
    echo "     ${networkinj}:" >> docker-compose.yml
    echo "       ipv4_address: '192.168.3.4'" >> docker-compose.yml
    
}

composehost(){
    echo "" >> docker-compose.yml
    echo "   networks:" >> docker-compose.yml
	echo "     - ${networkinj}" >> docker-compose.yml
	
}

composenetworks(){
    echo "" >> docker-compose.yml 
    echo "networks:" >> docker-compose.yml
    echo "   ${networkinj}:" >> docker-compose.yml
    echo "     driver: ${driver} " >> docker-compose.yml
    
}

composenetworksmacvlan(){
    echo "" >> docker-compose.yml  
    echo "networks:" >> docker-compose.yml
    echo "   ${networkinj}:" >> docker-compose.yml
    echo "     driver: macvlan" >> docker-compose.yml
    echo "     driver_opts:" >> docker-compose.yml
    echo "       parent: eth0" >> docker-compose.yml
    echo "     ipam:" >> docker-compose.yml
    echo "       config:" >> docker-compose.yml
    echo "         - subnet: '192.168.3.0/24'" >> docker-compose.yml
    echo "         - gateway: '192.168.3.1'" >> docker-compose.yml
    
}

#hace el volcado para el contenedor development
devcompose(){
    echo "" >> docker-compose.yml
    echo " dev:" >> docker-compose.yml
    echo "   build: './extras/apache/.'" >> docker-compose.yml
    echo "   ports:" >> docker-compose.yml
    echo "     # <Port exposed> : < MySQL Port running inside container>" >> docker-compose.yml
    echo "     - '80:80'" >> docker-compose.yml
    echo "     - '8000:8000'" >> docker-compose.yml
    echo "   volumes:" >> docker-compose.yml
    echo "     - ./App/apache/:/var/www/html/" >> docker-compose.yml
    echo "     - ./extras/hosts:/etc/hosts" >> docker-compose.yml
    echo "   networks:" >> docker-compose.yml
    
}

nodecompose(){
    echo "" >> docker-compose.yml
    echo " node:" >> docker-compose.yml
    echo "   build: './extras/node/.'" >> docker-compose.yml
    echo "   working_dir: /home/node/" >> docker-compose.yml
    echo "   environment:" >> docker-compose.yml
    echo "     - NODE_ENV=development" >> docker-compose.yml
    echo "   volumes:" >> docker-compose.yml
    echo "     - ./App/apache/:/home/apache/" >> docker-compose.yml
    echo "     - ./App/node/:/home/node/" >> docker-compose.yml
    echo "   ports:" >> docker-compose.yml
    echo "     # <Port exposed> : < MySQL Port running inside container>" >> docker-compose.yml
    echo "     - '3000:3000'" >> docker-compose.yml
    echo "   networks:" >> docker-compose.yml
      
}

ioniccompose(){
    echo "" >> docker-compose.yml 
    echo " node:" >> docker-compose.yml
    echo "   build: './extras/node/.'" >> docker-compose.yml
    echo "   working_dir: /home/node/" >> docker-compose.yml
    echo "   environment:" >> docker-compose.yml
    echo "     - NODE_ENV=development" >> docker-compose.yml
    echo "   volumes:" >> docker-compose.yml
    echo "     - ./App/node/:/home/node/" >> docker-compose.yml
    echo "   ports:" >> docker-compose.yml
    echo "     # <Port exposed> : < MySQL Port running inside container>" >> docker-compose.yml
    echo "     - '3000:3000'" >> docker-compose.yml
    echo "     - '8100:8100'" >> docker-compose.yml
     
}

#hace el volcado de default.conf basico
defaultconf(){
    echo "<VirtualHost *:80>" >> default.conf
	echo "  ServerAdmin webmaster@localhost" >> default.conf
	echo "  DocumentRoot /var/www/html/" >> default.conf
	echo "  SetEnv TYPO3_CONTEXT Development/Docker" >> default.conf
	echo "  <Directory /var/www/html/>" >> default.conf
	echo "    Options Indexes FollowSymLinks" >> default.conf
	echo "    AllowOverride All" >> default.conf
	echo "    Order allow,deny" >> default.conf
	echo "    Allow from all" >> default.conf
	echo "    Require all granted" >> default.conf
	echo "  </Directory>" >> default.conf
	echo "  ErrorLog /error.log" >> default.conf
	echo "  CustomLog /access.log combined" >> default.conf
	echo "</VirtualHost>" >> default.conf
	echo "" >> default.conf
}
#hace el volcado de default.conf para laravel
defaultconflaravel(){
    echo "<VirtualHost *:80>" >> default.conf
    echo "ServerAdmin webmaster@localhost" >> default.conf
    echo "DocumentRoot /var/www/html/$projectinj/public/" >> default.conf
    echo "SetEnv TYPO3_CONTEXT Development/Docker" >> default.conf
    echo "<Directory /var/www/html/$projectinj/public>" >> default.conf
    echo "Options Indexes FollowSymLinks" >> default.conf
    echo "AllowOverride All" >> default.conf
    echo "Order allow,deny" >> default.conf
    echo "Allow from all" >> default.conf
    echo "Require all granted" >> default.conf
    echo "</Directory>" >> default.conf
    echo "ErrorLog /error.log" >> default.conf
    echo "CustomLog /access.log combined" >> default.conf
    echo "</VirtualHost>" >> default.conf  
}

#llena el servidor node
fillserver(){
    echo "var express = require('express');" >> server.js
    echo "var app = express();" >> server.js
    echo "" >> server.js
    echo "app.get('/', function (req, res) {" >> server.js
    echo "res.send('Darien v4.0!');" >> server.js
    echo "});" >> server.js
    echo "" >> server.js
    echo "app.listen(3000, function () {" >> server.js
    echo "console.log('Example app listening on port 3000!');" >> server.js
    echo "});" >> server.js
}
#llena el servidor node para mostrar las instrucciones de ionic
fillserverionic(){
    echo "var express = require('express');" >> server.js
    echo "var app = express();" >> server.js
    echo "" >> server.js
    echo "app.get('/', function (req, res) {" >> server.js
    echo "res.send('Dentro de la carpeta /home/node hay dos scripts make.sh y serve.sh, ./make.sh crea el proyecto y ./serve.sh levanta el servidor de ionic');" >> server.js
    echo "});" >> server.js
    echo "" >> server.js
    echo "app.listen(3000, function () {" >> server.js
    echo "console.log('Example app listening on port 3000!');" >> server.js
    echo "});" >> server.js
}
