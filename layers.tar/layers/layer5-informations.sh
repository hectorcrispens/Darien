
showhelp(){
    echo ""
	echo " modo de empleo: darien [command]"
    echo " Como este programa interactúa con otras tecnologías, algunas veces necesita"
    echo " permiso de ADMINISTRADOR, cuando alguna opción tenga una salida con error,"
    echo " pruebe nuevamente como administrador o con sudo"
    echo ""
    echo ""
    #echo "----------------------------------------------------------------[${Cyan} help${Color_Off} ]---"
	echo -e "${Cyan} help                ${IRed}Visualiza el contenido de la ayuda ${Color_Off}"
    echo ""
	echo -e "${IGreen} [command]${Color_Off}"
	echo -e "${Cyan} apache              ${IRed}Crea un entorno con apache + mysql ${Color_Off}"
    echo -e "${Cyan} node                ${IRed}Crea un entorno con node + mysql${Color_Off}"
    echo -e "${Cyan} full                ${IRed}Crea un entorno con apache + node + mysql${Color_Off}"
    echo -e "${Cyan} laravel             ${IRed}Prepara el entorno para un proyecto laravel${Color_Off}"
    echo -e "${Cyan} lumen               ${IRed}Prepara el entorno para un proyecto lumen ${Color_Off}"
    echo -e "${Cyan} ionic               ${IRed}Prepara el entorno para un proyecto ionic ${Color_Off}"
    echo ""
    echo -e "${IGreen} <options> ${Color_Off}"
    echo -e "${Cyan}     --bridge        ${IRed}Agrega una red tipo bridge ${Color_Off}"
    echo -e "${Cyan}     --host          ${IRed}Agrega una red tipo host ${Color_Off}"
    echo -e "${Cyan}     --macvlan       ${IRed}Agrega una red tipo macvlan"
	echo ""
	#echo "------------------------------------------------------------------[ ${Cyan}up${Color_Off} ]---"
	echo -e "${Cyan} up                  ${IRed}Luego de creado el proyecto, up levanta el entorno virtual${Color_Off}"
	echo ""
	#echo "----------------------------------------------------------------[ ${Cyan}down${Color_Off} ]---"
	echo -e "${Cyan} down                ${IRed}Detiene la ejecución del entorno, sin eliminar las imagenes${Color_Off}"
	echo ""
    #echo "---------------------------------------------------------------[ ${Cyan}clear${Color_Off} ]---"
	echo -e "${Cyan} clear               ${IRed}Detiene el entorno y elimina las imagenes, ideal para recrear"
	echo -e "                     Cuando hay cambios en los archivos de configuración${Color_Off}"
    #echo "-------------------------------------------------------------[ ${Cyan}connect ${Color_Off}]---"
	echo -e "${Cyan} connect             ${IRed}Conecta con el contenedor de trabajo${Color_Off}"
	echo ""
    #echo "---------------------------------------------------------------[ ${Cyan}erase ${Color_Off}]---"
	echo -e "${Cyan} erase               ${IRed}Detiene el entorno y elimina el proyecto junto con los archivos${Color_Off}"
    echo ""
    echo -e "${IGreen} [command]${Color_Off}"
    echo -e "${Cyan} backup              ${IRed}Crea un archivo <nombre>.tar con el contenido del proyecto${Color_Off}"
    echo ""
    echo -e "${IGreen} <options> ${Color_Off}"
    echo -e "${Cyan}     --full          ${IRed}crea una copia del proyecto incluyendo los archivos de entorno${Color_Off}"
    echo -e "${Cyan}     --single        ${IRed}Solo incluye los archivos del proyecto en si App <folder>${Color_Off}"
    echo ""
}

lgoo(){
echo -e "${Cyan}🄳🄰🅁🄸🄴🄽${Color_Off}"

}
lsec1(){
    sleep 1
    echo -ne "\r${Cyan}-[ ${IRed}$since ${Cyan}]${Color_Off}"

}
lsec2(){
    sleep 1
    echo -ne "\r${Cyan}-------[ ${IRed}$since ${Cyan}]${Color_Off}"

}
lsec3(){
    sleep 1
    echo -ne "\r${Cyan}---------------[ ${IRed}$since ${Cyan}]${Color_Off}"

}
lsec4(){
    sleep 1
    echo -ne "\r${Cyan}---------------------[ ${IRed}$since ${Cyan}]${Color_Off}"

}
lsec5(){
    sleep 1
    echo -ne "\r${Cyan}----------------------------[ ${IRed}$since ${Cyan}]${Color_Off}"

}
lsec6(){
    sleep 1
    echo -ne "\r${Cyan}-----------------------------------[ ${IRed}$since ${Cyan}]${Color_Off}"

}
lsec7(){
    sleep 1
    echo -ne "\r${Cyan}------------------------------------------[ ${IRed}$since ${Cyan}]${Color_Off}"

}

lsec8(){
    sleep 1
    echo -ne "\r${Cyan}-------------------------------------------------[ ${IRed}$since ${Cyan}] ${Color_Off}               "

}
