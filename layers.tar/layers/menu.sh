
while [ -n "$1" ]; do # while loop starts

			case "$1" in
            help)
                showhelp
                break
                ;;
			
            apache)
                flag=$2
                command=$1
                 buildapache
                echo " "
                break
                ;;
            node)
              
                flag=$2
                command=$1 
                 buildnode
                 
                 echo " "
                break
                ;;
            full)
               
                flag=$2
                command=$1
                buildfull
                
                 echo " "
                break
                ;;
            laravel)
             
                flag=$2
                command=$1
                buildlaravel
                
                 echo " "
                break
                ;;
            lumen)
             
                flag=$2
                command=$1
                buildlumen
                
                 echo " "
                break
                ;;
            ionic)
               
                flag=$2
                command=$1
                buildionic
                
                break
                ;;
            up)
              
                taskup
                break
                ;;
            down)
              
                taskdown
                break
                ;;
            connect)
            
                taskconnect
                break
                ;;
            clear)
             
                taskclear
                break
                ;;
            erase)
               
                taskerase
                break
                ;;
            show)
                taskshow
                break
                ;;
            backup)
                flag=$2
                taskbackup
                break
                ;;


            --)
                shift

                break
                ;;

             *) echo "Option $1 not recognized" ;;

             esac
       shift

done

